package com.github.handioq.diber.service.impl;

public class StatisticServiceImpl {

}
