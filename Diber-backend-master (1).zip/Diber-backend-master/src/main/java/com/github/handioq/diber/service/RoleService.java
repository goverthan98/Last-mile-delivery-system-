package com.github.handioq.diber.service;

import com.github.handioq.diber.model.entity.Role;

public interface RoleService {

    Role findRole(long id);

}