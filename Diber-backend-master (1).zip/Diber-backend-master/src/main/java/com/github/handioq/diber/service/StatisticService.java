package com.github.handioq.diber.service;

public interface StatisticService {

}
