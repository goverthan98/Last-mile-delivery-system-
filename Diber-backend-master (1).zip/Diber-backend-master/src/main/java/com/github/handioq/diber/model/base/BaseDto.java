package com.github.handioq.diber.model.base;

public abstract class BaseDto {


}
