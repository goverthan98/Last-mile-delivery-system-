package com.github.handioq.diber.repository;

public interface StatisticRepository {
}
